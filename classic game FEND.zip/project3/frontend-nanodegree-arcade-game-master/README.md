# Classic Arcade Game Clone Project

# Classic Arcade Game Clone Project

### To run
----------------------------
- Download the application from [here](https://github.com/moody0735/classic3project)
- Select ```index.html``` to start the app.

#### How to play
----------------------------

- Get to the water.
- Avoid bugs.
-And Go ON!

## Controls
----------------------------

* The player can be moved with the ***arrow keys***